#pragma once
#include <iostream>
#include <sstream>
#include <string.h>
#include <stdio.h>
#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/video/video.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/objdetect/objdetect.hpp>
#include <opencv2/video/tracking.hpp>
#include <cmath>
#include <vector>
#include <typeinfo>

using namespace std;
using namespace cv;

class CarSpeed
{
	double area, ar;
	Mat frame, fore, img, prevImg, temp, gray, vehicle_ROI, img_temp;
	Ptr<BackgroundSubtractorMOG2> bg = createBackgroundSubtractorMOG2(500, 25, false);
	int count;


	vector<vector<Point> > contours;
	vector<Point2f> prevContoursCenters;
	vector<Point2f> tempContoursCenters;
	vector<Rect> cars;



	// start and end times
	time_t start, end;
	// fps calculated using number of frames / seconds
	double fps;
	// frame counter
	int counter = 0;
	// floating point seconds elapsed since start
	double sec;

public:
	bool isInit = false;

	void Init(Mat Img);
	Mat getSpeed(Mat Img);

private:
	double get_speed(cv::Mat& frame, vector<Point>& contour, Point2f center, float radius, vector<Point2f> prevContourCenters, double fps);
};

