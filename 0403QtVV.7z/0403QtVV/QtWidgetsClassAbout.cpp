#include "QtWidgetsClassAbout.h"

QtWidgetsClassAbout::QtWidgetsClassAbout(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
}

QtWidgetsClassAbout::~QtWidgetsClassAbout()
{
}
